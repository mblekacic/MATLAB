function y = delta(x)
if x==0
    y=1/sqrt(2);
else
    y=1;
end
